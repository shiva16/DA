SELECT username
FROM salespeople
WHERE gender= 'Female'
ORDER BY hire_date
LIMIT 10
